---
project: "[[Projeto Exemplo]]"
summary:
tags: project/projeto_exemplo/nota_projeto
type: project_note
created: "[[2026-01-25]]"
---




