````tabs
tab: <% tp.system.prompt("first tab")%>



tab: <% tp.system.prompt("Sec tab")%>

````
