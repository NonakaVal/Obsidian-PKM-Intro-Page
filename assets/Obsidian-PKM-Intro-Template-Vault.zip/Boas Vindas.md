
# Introdução 


> ⚠️ Está vault é um template -   Não está Padrão do [Obisidian.md](https://obsidian.md/) -  Leia A apresentação Abaixo para o uso 

> 🔗 [Github Template Repo](https://github.com/NonakaVal/Obsidian-PKM-Intro-Template-Vault) -  ⬇️ `.zip` [Download Link](https://github.com/NonakaVal/Obsidian-PKM-Intro-Template-Vault/raw/refs/heads/main/Obsidian-PKM-Intro-Template-Vault.zip)

# Próximos Passos 


`BUTTON[workspaces]` :LiOption: `BUTTON[readme]` 

```meta-bind-button
label: Começe Aqui (Tópicos em Ordem)
hidden: true
icon: space
class: ""
id: workspaces
style: destructive
actions:
  - type: command
    command: workspaces:load
```

```meta-bind-button
label: README (Leia Me)
hidden: true
icon: info
class: ""
id: readme
style: primary
actions:
  - type: command
    command: obsidian-hotkeys-for-specific-files:README.md-new-tab
```

