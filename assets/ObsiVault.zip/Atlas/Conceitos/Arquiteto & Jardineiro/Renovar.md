---
up: "[[++ Gestão de Conhecimento]]"
collection: "[[Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
~ [[Architect]]  

> [!scale] [[Construir]] | [[Renovar]] — [[Jardineiro]] ⤵️

Quando você tem um mapa de conteúdo mais antigo ou que sente que precisa de algum tipo de atualização, você pode dar a ele a tag `architect/renovate`.  