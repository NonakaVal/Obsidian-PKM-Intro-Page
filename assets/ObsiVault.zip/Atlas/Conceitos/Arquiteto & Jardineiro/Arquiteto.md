---
up: "[[++ Gestão de Conhecimento]]"
collection: "[[Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
> [!scale] [[Construir]] | [[Renovar]] — [[Jardineiro]] ⤵️

Quando você tiver um **mapa de conteúdo que precisa de ajustes**, pode adicionar a tag `architect` nessa nota. Assim, através das **visões de Arquiteto** abaixo, você poderá encontrá-la no momento certo.

**Chave:** 🧱 Construir | 🪜 Renovar  
