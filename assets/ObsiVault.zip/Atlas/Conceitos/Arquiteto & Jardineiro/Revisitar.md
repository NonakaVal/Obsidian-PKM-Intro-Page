---
up: "[[++ Gestão de Conhecimento]]"
collection: "[[Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
~ [[Jardineiro]]

> [!trees] [[Plante]] | **[[Cultive]]** | [[Questione]] | [[Replantar]] | [[Revitalizar]] | [[Revisitar]] — [[Arquiteto]] ⤴️  

Se você marcou notas com `#garden/revisit`, então você quer **relê-las.**  
Talvez queira um lembrete, um reforço, ou simplesmente reler por qualquer motivo, pois você sabe que nem tudo que brilha é 