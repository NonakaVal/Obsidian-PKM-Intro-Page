---
up: "[[++ Gestão de Conhecimento]]"
collection: "[[Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
Áreas são esferas de responsabilidade contínuas na sua vida que exigem manutenção constante, mas nunca são "concluídas".

Características das Áreas:
- **Sem prazo final**: Você nunca termina de cuidar da saúde ou das finanças
- **Padrão de qualidade**: Você define como quer que cada área esteja 
- **Geram projetos**: Quando uma área precisa de atenção, você cria projetos específicos

Exemplos práticos:
- **Área: Saúde**
	- Projetos que surgem: "Perder 5kg em 3 meses", "Fazer checkup anual"
	- Conteúdo da área: Exames, histórico médico, treinos atuais
- **Área: Finanças**
	- Projetos que surgem: "Quitar cartão de crédito", "Criar fundo de emergência"
	- Conteúdo da área: Orçamento mensal, investimentos, contas a pagar
- **Área: Carreira/Trabalho**
	- Projetos que surgem: "Concluir certificação X", "Pedir aumento"
	- Conteúdo da área: Currículo, avaliações, objetivos profissionais
