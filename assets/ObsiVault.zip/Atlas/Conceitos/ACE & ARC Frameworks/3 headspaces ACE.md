---
up: "[[++ Gestão de Conhecimento]]"
collection: "[[Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
- **A – Atlas** → Guarda referências e conhecimento geral. É o “mapa” das suas ideias, conceitos e temas.
- **C – Calendário** → Armazena tudo que está ligado a datas: eventos, prazos, registros cronológicos.
- **E – Esforços** → Contém seus projetos, tarefas e iniciativas que exigem ação.


---
---

<div style="position:relative; min-height:200px; border:1px dashed #ccc">
  <img src="atlas-f.png" alt="Imagem" width="190"
       style="position:absolute; top:50%; left:50%; transform:translate(-50%, -50%);">
</div>


