---
up: "[[++ Gestão de Conhecimento]]"
collection: "[[Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
Ela é uma forma simples de guardar aqueles tipos de notas de controle e outros arquivos.

- Notas sobre notas: anotações relacionadas ao próprio vault  
- Não-notas: imagens, PDFs e outros tipos de arquivos  
- Notas utilitárias: templates  
- Notas arquivadas  

