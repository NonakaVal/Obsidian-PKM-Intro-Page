---
created: '[[<% tp.date.now("YYYY-MM-DD") %>]]'
tags:
  - Journal
---
# ❓ Sua Pergunta é
- Breve descrição da questão.

## ✅ Argumentos a Favor
1. 

## ⛔ Argumentos Contra
1. 

## 🔀 Alternativas Consideradas
1. 

## 📦 Recursos
- Link para qualquer informação relevante

## 🧮 Cálculo de Prós e Contras

Pró | Valor (0-10) | Contra | Valor (0-10)
:--:|:-----|:------:|:------:|
Pró 1 | 10 | Contra 1 | 10 |
Pró 2 | 10 | Contra 2 | 10 |
Pró 3 | 10 | Contra 3 | 10 |
Pró 4 | 10 | Contra 4 | 10 |
Pró 5 | 10 | Contra 5 | 10 |
Pró 6 | 10 | Contra 6 | 10 |
Pró 7 | 10 | Contra 7 | 10 |
Pró 8 | 10 | Contra 8 | 10 |
Pró 9 | 10 | Contra 9 | 10 |
Pró 10 | 10 | Contra 10 | 10 |
**Total Prós** | 100 | **Total Contras** | 100 |

❗❗❗ Se o total dividido por 100 não tiver ao menos **20% de diferença**, adicione mais prós e contras para refinar a decisão.
