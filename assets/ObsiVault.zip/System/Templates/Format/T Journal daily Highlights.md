---
created:
  - "{{date: DD-MM-YYYY}} {{time}}"
tags:
  - Journal
---
# Highlights
_List the best moments, achievements, or positive experiences from your day. Capture what made these moments significant to enhance your appreciation and understanding of the good in your life._
- 

# Lowlights
_Identify the most challenging, frustrating, or disappointing aspects of your day. Describe these situations to better understand and address these challenges in the future._
- 

# Lessons Learned
_Reflect on what you learned from the day's highs and lows. Consider insights about yourself, interactions, or life situations that could influence future decisions._
- 

# Areas for Improvement
_Based on today's lowlights and lessons, pinpoint specific areas to focus on for personal growth. Outline actionable steps or new habits to adopt._
- 
