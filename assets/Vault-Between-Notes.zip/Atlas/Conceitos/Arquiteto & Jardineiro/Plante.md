---
up:
  - "[[Jardineiro]]"
---
~ [[Jardineiro]]  

> [[Plante]] | **[[Cultive]]** | [[Questione]] | [[Replantar]] | [[Revitalizar]] | [[Revisitar]] — [[Arquiteto]] ⤴️  

Se você marcou notas com `#garden/plant`, 