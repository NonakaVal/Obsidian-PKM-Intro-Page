---
up:
  - "[[+ Arquiteto & Jardineiro]]"
dg-publish: true
---
>  [[Construir]] | [[Renovar]] — [[Jardineiro]] ⤵️

Quando você tiver um **mapa de conteúdo que precisa de ajustes**, pode adicionar a tag `architect` nessa nota. Assim, através das **visões de Arquiteto** abaixo, você poderá encontrá-la no momento certo.

**Chave:** 🧱 Construir | 🪜 Renovar  
