---
up:
  - "[[Arquiteto]]"
---
~ [[Arquiteto]] 

> [[Construir]] | [[Renovar]] — [[Jardineiro]] ⤵️

Quando você tem um **mapa de conteúdo novo ou inacabado** que ainda precisa de atenção, atribua a tag `#architect/build`.  

