---
created: '[[<% tp.date.now("YYYY-MM-DD") %>]]'
tags:
  - Journal
---

# Avaliação do Humor 🎭
_Atribua um valor numérico ao seu humor geral do dia; escolha uma escala que faça sentido para você (ex.: 1–5 ou 1–10)._
- 

# Emoções Sentidas 💬
_Anote as emoções específicas que você sentiu ao longo do dia, como alegria, tristeza, ansiedade ou raiva._
- 

# Gatilhos ⚡
_Identifique eventos, situações ou pensamentos que impactaram seu humor — de forma positiva ou negativa._
- 

# Estratégias de Enfrentamento 🧘‍♀️
_Registre as técnicas ou atividades que você usou para lidar com suas emoções hoje — como respiração profunda, exercícios físicos ou conversar com alguém._
- 

# Reflexão 🌙
_Faça um resumo do seu dia, destacando percepções ou aprendizados sobre seu bem-estar emocional._
- 
