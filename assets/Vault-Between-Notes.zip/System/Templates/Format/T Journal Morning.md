---
created: '[[<% tp.date.now("YYYY-MM-DD") %>]]'
tags:
  - Journal
---

# Gratidão 🙏
_Tire um momento para escrever pelo que você realmente é grato — seja algo grande ou pequeno. A gratidão define um tom positivo para o dia e fortalece o sentimento de apreciação._
- 

# Principais Prioridades 🎯
_Anote suas tarefas ou metas mais importantes de hoje. Foque no que realmente importa e o aproxima da sua visão maior._
- 

# Check-in de Humor 💭
_Reflita com honestidade sobre como você está se sentindo agora. Reconhecer suas emoções ajuda a conduzir o dia com equilíbrio e intenção._
- 

# Motivação ou Afirmação ✨
_Escreva (ou escolha) uma citação, mantra ou afirmação que o inspire. Deixe que ela guie sua mentalidade e ações ao longo do dia._
- 
