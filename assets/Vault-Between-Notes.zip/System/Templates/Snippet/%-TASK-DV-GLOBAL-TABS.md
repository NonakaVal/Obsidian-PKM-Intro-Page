
````tabs
tab: Calendar tasks
![[@_dataview_Calendar-tasks]]

tab: Efforts Tasks
![[@_dataview-efforts-tasks]]

tab: All tasks
![[@_dataview-all-tasks]]
````

