<iframe 
  src="<% tp.system.prompt("link")%>" 
  width="100%" 
  height="600" 
  frameborder="0"
  style="border:1px solid #ccc;">
</iframe>
