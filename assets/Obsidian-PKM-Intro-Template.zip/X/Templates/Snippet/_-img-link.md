

![img<%tp.file.cursor()%>](<% tp.system.prompt("link .png .jpg etc..")%>)