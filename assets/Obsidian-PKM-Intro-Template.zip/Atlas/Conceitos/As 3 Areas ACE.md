---
collection:
  - "[[+ ACE Pack]]"
---
- **A – Atlas** → Guarda referências e conhecimento geral. É o “mapa” das suas ideias, conceitos e temas.
- **C – Calendário** → Armazena tudo que está ligado a datas: eventos, prazos, registros cronológicos.
- **E – Esforços** → Contém seus projetos, tarefas e iniciativas que exigem ação.


---
---

![img](atlas-f.png)